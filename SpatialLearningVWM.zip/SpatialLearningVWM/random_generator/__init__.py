from sys import stdout

import random_generator as rg

print("Loading:\n")

a = rg.start_loc()
b = rg.platform_locations()

print("Start Sets:" + a + "\nPlatform Locations" + b)

